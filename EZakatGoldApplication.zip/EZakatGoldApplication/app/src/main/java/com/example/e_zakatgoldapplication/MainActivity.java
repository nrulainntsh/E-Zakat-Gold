package com.example.e_zakatgoldapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener{

    EditText etGram;
    EditText etValue;
    Spinner goldType;
    Button btnCalculate, btnReset;
    TextView tvOutput, tvOutput2, tvOutput3;
    ArrayAdapter<CharSequence> adapter;
    float goldWeight;
    float goldValue;

    SharedPreferences sharedPref;
    SharedPreferences sharedPref2;
    private Menu menu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        goldType = (Spinner) findViewById(R.id.goldType);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.goldType_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        goldType.setAdapter(adapter);

        etGram = (EditText) findViewById(R.id.gram);
        etValue = (EditText) findViewById(R.id.goldValue);
        btnCalculate = (Button) findViewById(R.id.calculate);
        btnReset = (Button) findViewById(R.id.reset);
        tvOutput = (TextView) findViewById(R.id.tvOutput);
        tvOutput2 = (TextView) findViewById(R.id.tvOutput2);
        tvOutput3 = (TextView) findViewById(R.id.tvOutput3);

        btnCalculate.setOnClickListener(this);
        btnReset.setOnClickListener(this);
        goldType.setOnItemSelectedListener(this);

        sharedPref = this.getSharedPreferences("weight", Context.MODE_PRIVATE);
        //load the data
        goldWeight = sharedPref.getFloat("weight", 0.0F);

        sharedPref2 = this.getSharedPreferences("value", Context.MODE_PRIVATE);
        goldValue = sharedPref2.getFloat("value", 0.0F);

        etGram.setText("" +goldWeight);
        etValue.setText("" +goldValue);

    }

    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);

        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.aboutUs:
                //Toast.makeText(this, "This is about E-Zakat Gold Application", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(this, AboutActivity.class);
                startActivity(intent);
                break;
        }

        switch (item.getItemId()){
            case R.id.calculator:
                //Toast.makeText(this, "This is about E-Zakat Gold Application", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {

        try{
            switch (v.getId()){
                case R.id.calculate:
                    calculate();
                    break;

                case R.id.reset:
                    etGram.setText("");
                    etValue.setText("");
                    tvOutput.setText("");
                    tvOutput2.setText("");
                    tvOutput3.setText("");

                    break;
            }
        } catch(java.lang.NumberFormatException nfe){
            Toast.makeText(this,"Please enter a valid number", Toast.LENGTH_SHORT).show();
        } catch (Exception exp){
            Toast.makeText(this, "Unknown Exception" + exp.getMessage(), Toast.LENGTH_SHORT).show();

            Log.d("Exception", exp.getMessage());
        }
    }

    private void calculate() {
        DecimalFormat df = new DecimalFormat("##,###,###.00");
        float goldWeight = Float.parseFloat(etGram.getText().toString());
        float goldValue = Float.parseFloat(etValue.getText().toString());
        String type = goldType.getSelectedItem().toString();
        double totalValGold;
        double uruf;
        double zakatPayable;
        double totalZakat;
        //saving the data
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putFloat("weight", goldWeight);
        editor.apply();
        editor = sharedPref2.edit();
        editor.putFloat("value", goldValue);
        editor.apply();

        if (type.equals("Keep")){
            totalValGold = goldWeight * goldValue;
            uruf = goldWeight - 85;

            if(uruf >= 0.0) {
                zakatPayable = uruf * goldValue;
                totalZakat = zakatPayable * 0.025;
            }

            else{
                zakatPayable = 0.0;
                totalZakat = zakatPayable * 0.025;
            }
        }

        else{
            totalValGold = goldWeight * goldValue;
            uruf = goldWeight - 200;

            if(uruf >= 0.0) {
                zakatPayable = uruf * goldValue;
                totalZakat = zakatPayable * 0.025;
            }

            else{
                zakatPayable = 0.0;
                totalZakat = zakatPayable * 0.025;
            }
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Calculation Result:\n\n");
        builder.setMessage("" +
                "Total value of the gold: RM " +df.format(totalValGold) +
                "\n\nTotal gold value that is zakat payable: RM " +df.format(zakatPayable) +
                "\n\nTotal zakat: RM " +df.format(totalZakat));

        //add button
        builder.setPositiveButton("Continue", null);

        //create and show the alert dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}